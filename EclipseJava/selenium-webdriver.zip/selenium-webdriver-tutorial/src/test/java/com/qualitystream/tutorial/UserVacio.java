package com.qualitystream.tutorial;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class UserVacio {
	
	private WebDriver driver;
	By registerLinkLocator = By.linkText("REGISTER");
	By registerPageLocator = By.xpath("//img[@src='/images/masts/mast_register.gif']");
	
	
	By registerBtnLocator = By.name("register");
	
	By userLocator = By.name("userName");
	By passLocator = By.name("password");
	By signInBtnLocator = By.name("login");
	
	By homePageLocator = By.xpath("//img[@src='/images/masts/mast_flightfinder.gif']");
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.gecko.driver", "./src/test/resources/chromedriver/geckoDriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}


	@Test
	public void registerUserVacio() throws InterruptedException {
	    Thread.sleep(2000);
	    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

	    driver.manage().window().setSize(new Dimension(1366, 720));

	   
	    WebElement usernameField = driver.findElement(By.name("username"));
	    WebElement passwordField = driver.findElement(By.name("password"));
	    WebElement loginButton = driver.findElement(By.cssSelector(".oxd-button"));

	    
	    if (usernameField.getText().isEmpty()) {
	       
	    	driver.findElement(By.name("password")).sendKeys("admin123");
	    	driver.findElement(By.cssSelector(".oxd-button")).click();
	        WebElement requiredMessage = driver.findElement(By.xpath("//*[text()='Required']"));
	        if (requiredMessage.isDisplayed()) {
	            System.out.println("El mensaje 'Required' se muestra correctamente.");
	        } else {
	            System.out.println("El mensaje 'Required' no se muestra.");
	        }
	    } else {
	      
	        usernameField.sendKeys("admin");
	        passwordField.sendKeys("admin123");
	        loginButton.click();
	    }
	}
	
	
	@Test
	public void UserPasswordVacio() throws InterruptedException {
		 Thread.sleep(2000);
		    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

		    driver.manage().window().setSize(new Dimension(1366, 720));

		   
		    WebElement usernameField = driver.findElement(By.name("username"));
		    WebElement passwordField = driver.findElement(By.name("password"));
		    WebElement loginButton = driver.findElement(By.cssSelector(".oxd-button"));

		    
		    if (usernameField.getText().isEmpty() && passwordField.getText().isEmpty()) {
		       
		    	driver.findElement(By.name("password")).sendKeys("");
		    	driver.findElement(By.name("username")).sendKeys("");
		    	driver.findElement(By.cssSelector(".oxd-button")).click();
		        WebElement requiredMessage = driver.findElement(By.xpath("//*[text()='Required']"));
		        if (requiredMessage.isDisplayed()) {
		            System.out.println("El mensaje 'Required' se muestra correctamente.");
		        } else {
		            System.out.println("El mensaje 'Required' no se muestra.");
		        }
		    } else {
		      
		        usernameField.sendKeys("admin");
		        passwordField.sendKeys("admin123");
		        loginButton.click();
		    }
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}

		
	
	
	
}
