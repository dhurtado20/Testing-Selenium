package com.qualitystream.tutorial;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class UpdateDeleteUser {


	private WebDriver driver;
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.gecko.driver", "./src/test/resources/chromedriver/geckoDriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
	}

	
	
	
	
	@Test
	public void UpdateUser() throws InterruptedException {
	   
	
		Thread.sleep(2000);
		Thread.sleep(2000);
 	    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

	    driver.manage().window().setSize(new Dimension(1366, 720));

	    driver.findElement(By.name("username")).sendKeys("Admin");
	    driver.findElement(By.name("password")).sendKeys("admin123");
	    driver.findElement(By.cssSelector(".oxd-button")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[text()='Admin']")).click();
	   Thread.sleep(2000);
			  driver.findElement(By.cssSelector(".oxd-icon-button > .bi-caret-down-fill")).click();
			  
			  Thread.sleep(4000);   
			    driver.findElement(By.xpath("(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[1]")).click();
			    Thread.sleep(4000);
			    driver.findElement(By.xpath("(//div[@role='listbox']//child::div)[3]")).click();
			    Thread.sleep(000);
			    driver.findElement(By.xpath("(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[2]")).click();
			    Thread.sleep(000);						
			    driver.findElement(By.xpath("(//div[@role='listbox']//child::div)[3]")).click();
			   
			  Thread.sleep(2000);
			//  driver.findElement(By.xpath("//div[@id=\'app\']/div/div[2]/div[2]/div/div/div[2]/form/div/div/div/div/div[2]/input")).click();
		//	  Thread.sleep(2000);
			  driver.findElement(By.cssSelector(".oxd-input--focus")).sendKeys("1Diana123");
			  Thread.sleep(2000);
			    driver.findElement(By.cssSelector(".oxd-grid-item:nth-child(1)")).click();
			    driver.findElement(By.cssSelector(".orangehrm-left-space")).click();
			    driver.findElement(By.cssSelector(".bi-pencil-fill")).click();
			    driver.findElement(By.xpath("//div[@id=\'app\']/div/div[2]/div[2]/div/div/form/div/div/div[4]/div/div[2]/input")).click();
			    driver.findElement(By.cssSelector(".oxd-input--focus")).sendKeys("1Diana1234");
			    driver.findElement(By.cssSelector(".oxd-grid-item:nth-child(3)")).click();
			    driver.findElement(By.cssSelector(".bi-check")).click();
			    driver.findElement(By.xpath("//input[@type=\'password\']")).click();
			    driver.findElement(By.cssSelector(".oxd-input--focus")).sendKeys("Diana12345");
			    driver.findElement(By.cssSelector(".oxd-button--secondary")).click();
			    driver.findElement(By.xpath("(//input[@type=\'password\'])[2]")).click();
			    driver.findElement(By.cssSelector(".oxd-input--focus")).sendKeys("Diana12345");
			    driver.findElement(By.cssSelector(".oxd-button--secondary")).click();
		    
		    
	
	}
	

	@Test
	public void DeleteUser() throws InterruptedException {
	   
	
		Thread.sleep(2000);
 	    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

	    driver.manage().window().setSize(new Dimension(1366, 720));

		
		    driver.findElement(By.name("username")).sendKeys("Admin");
		    driver.findElement(By.name("password")).click();
		    driver.findElement(By.name("password")).sendKeys("admin123");
		    driver.findElement(By.cssSelector(".oxd-button")).click();
		    Thread.sleep(3000);
		    driver.findElement(By.xpath("//span[text()='Admin']")).click();
		    Thread.sleep(2000);
		    driver.findElement(By.cssSelector(".oxd-main-menu-item-wrapper:nth-child(1) .oxd-text")).click();
		    driver.findElement(By.xpath("//div[@id=\'app\']/div/div[2]/div[2]/div/div/div[2]/form/div/div/div/div/div[2]/input")).click();
		    driver.findElement(By.cssSelector(".oxd-input--focus")).sendKeys("1Diana1234");
		    driver.findElement(By.cssSelector(".orangehrm-left-space")).click();
		    Thread.sleep(4000);
		    driver.findElement(By.cssSelector(".bi-trash")).click();
		    driver.findElement(By.cssSelector(".oxd-button--label-danger")).click();

			Thread.sleep(8000);
	};
		    

	
	@After
	public void tearDown() {
		driver.quit();
	}
}
