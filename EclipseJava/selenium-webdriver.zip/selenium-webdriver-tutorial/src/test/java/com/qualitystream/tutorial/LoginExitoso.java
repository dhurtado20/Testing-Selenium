package com.qualitystream.tutorial;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginExitoso {

	
	private WebDriver driver;
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.gecko.driver", "./src/test/resources/chromedriver/geckoDriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		
	}

	@Test
	public void usernameyPasswordcorrectos() {
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		    driver.manage().window().setSize(new Dimension(1382, 736));
		    driver.findElement(By.name("username")).sendKeys("Admin");
		    driver.findElement(By.name("password")).sendKeys("admin123");
		    driver.findElement(By.cssSelector(".oxd-button")).click();
		    driver.close();
		    
		    
	
	}
	
	@After
	public void tearDown() {
		//driver.quit();
	}
}
