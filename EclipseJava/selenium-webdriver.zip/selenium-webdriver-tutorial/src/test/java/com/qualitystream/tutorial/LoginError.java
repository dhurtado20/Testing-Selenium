package com.qualitystream.tutorial;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.JavascriptExecutor;

public class LoginError {
	
	private WebDriver driver;
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.gecko.driver", "./src/test/resources/chromedriver/geckoDriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	@Test
	public void LoginIncorrecto() {
		
	
	WebElement usernameField = driver.findElement(By.name("username"));
    WebElement passwordField = driver.findElement(By.name("password"));
    
   
    usernameField.sendKeys("usuario_incorrecto");
    passwordField.sendKeys("contraseña_incorrecta");
    
   
    WebElement loginButton = driver.findElement(By.cssSelector("button[type='submit']"));
    loginButton.click();
    
   
    WebDriverWait wait = new WebDriverWait(driver, 10); 
    WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".oxd-alert-content")));
    
 
    if (errorMessage.getText().contains("Invalid credentials")) {
        System.out.println("Test Passed: El mensaje 'Invalid credentials' es visible.");
    } else {
        System.out.println("Test Failed: El mensaje 'Invalid credentials' no fue encontrado.");
    }
	
	}
	@After
	public void tearDown() {
		//driver.quit();
	}

}
