package com.qualitystream.tutorial;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class CretaeUser {

	private WebDriver driver;
	
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.gecko.driver", "./src/test/resources/chromedriver/geckoDriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	@Test
	public void CreateUsuario() throws InterruptedException {
		

		Thread.sleep(2000);
 	    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

	    driver.manage().window().setSize(new Dimension(1366, 720));

	    driver.findElement(By.name("username")).sendKeys("Admin");
	    driver.findElement(By.name("password")).sendKeys("admin123");
	    driver.findElement(By.cssSelector(".oxd-button")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//span[text()='Admin']")).click();
	   Thread.sleep(2000);
	    driver.findElement(By.xpath("//button[contains(.,'Add')]")).click();
	    Thread.sleep(4000);   
	    driver.findElement(By.xpath("(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[1]")).click();
	    Thread.sleep(4000);
	    driver.findElement(By.xpath("(//div[@role='listbox']//child::div)[2]")).click();
	   
	    //driver.findElement(By.cssSelector(".oxd-autocomplete-text-input > input")).sendKeys("manda akhil user");
	    WebElement cssSelectorField = driver.findElement(By.cssSelector(".oxd-autocomplete-text-input > input"));
        cssSelectorField.sendKeys("Diana Hurtado");
        WebElement option = new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='listbox']//span[contains(text(),'man')]")));
        option.click();
	    Thread.sleep(000);
	    driver.findElement(By.xpath("(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[2]")).click();
	    Thread.sleep(000);						
	    driver.findElement(By.xpath("(//div[@role='listbox']//child::div)[2]")).click();
	  /*  {
	      WebElement element = driver.findElement(By.cssSelector(".oxd-grid-item:nth-child(2) .oxd-input"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).release().perform();
	    }*/
	    Thread.sleep(000);
	    driver.findElement(By.xpath("//div[2]/input")).click();
	    driver.findElement(By.xpath("//div[2]/input")).sendKeys("1Diana123");
	    driver.findElement(By.cssSelector(".oxd-input--focus")).click();
	    driver.findElement(By.xpath("//input[@type=\'password\']")).click();
	    driver.findElement(By.xpath("//input[@type=\'password\']")).sendKeys("Diana123");
	    driver.findElement(By.xpath("(//input[@type=\'password\'])[2]")).click();
	    driver.findElement(By.xpath("(//input[@type=\'password\'])[2]")).sendKeys("Diana123");
	    driver.findElement(By.cssSelector(".oxd-button--secondary")).click();
        Thread.sleep(8000);
 	   
	   
		/*driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	    driver.manage().window().setSize(new Dimension(883, 998));
	    driver.findElement(By.name("username")).click();
	    driver.findElement(By.name("username")).sendKeys("Admin");
	    driver.findElement(By.name("password")).sendKeys("admin123");
	    driver.findElement(By.cssSelector(".oxd-button")).click();
	    driver.findElement(By.cssSelector(".oxd-main-menu-item-wrapper:nth-child(1) .oxd-icon")).click();
	    driver.findElement(By.cssSelector(".oxd-button--secondary:nth-child(1)")).click();
	    driver.findElement(By.cssSelector(".bi-chevron-left")).click();*/
	  
        }
    

      
	
	
	@After
	public void tearDown() {
		driver.quit();
	}

}


